#!/bin/bash
./frpc -c frpc.ini